package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * @author
 * @date 2019/12/9 17:04
 */
@Component
@Scope(value = "prototype")
public class Man {

//    Person person;
//
//    public Man(Person person) {
//        this.person = person;
//    }

    @Autowired
    Person person;

//    Person person;
//
//    @Autowired
//    public void setPerson(Person person) {
//        this.person = person;
//    }
}