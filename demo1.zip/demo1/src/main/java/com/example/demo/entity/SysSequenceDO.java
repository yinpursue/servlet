package com.example.demo.entity;

/**
 * 序列号
 * @author
 * @date 2019/12/4 14:59
 */
public class SysSequenceDO {
    private String name;
    private Long currentValue;
    private int increment;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getCurrentValue() {
        return currentValue;
    }

    public void setCurrentValue(Long currentValue) {
        this.currentValue = currentValue;
    }

    public int getIncrement() {
        return increment;
    }

    public void setIncrement(int increment) {
        this.increment = increment;
    }

    @Override
    public String toString() {
        return "SysSequenceDO{" +
                "name='" + name + '\'' +
                ", currentValue=" + currentValue +
                ", increment=" + increment +
                '}';
    }
}
