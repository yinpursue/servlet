package com.example.demo.controller;

/**
 * @author
 * @date 2019/12/5 10:15
 */
public class Singleton2 {

    private Singleton2(){

    }

    public static class Inner{
        private static Singleton2 singleton2 = new Singleton2();
    }
    public Singleton2 getInstance(){
        return Inner.singleton2;
    }
}
