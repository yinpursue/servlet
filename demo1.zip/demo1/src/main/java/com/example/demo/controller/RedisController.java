package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author
 * @date 2019/12/4 16:36
 */
@RestController
public class RedisController {
    @Autowired
    private RedisTemplate redisTemplate;

    @GetMapping("/set")
    public String setMsg(@RequestParam(value = "key") String key, @RequestParam(value = "msg") String msg){
        redisTemplate.opsForValue().set(key,msg);
        return "success";
    }

    @GetMapping("/get")
    public String getMsg(@RequestParam(value = "key") String key){
        return (String)redisTemplate.opsForValue().get(key);
    }
    @GetMapping("/getAndIncr")
    public Long getAndIncr(@RequestParam(value = "key") String key){
        return (Long)redisTemplate.opsForValue().increment(key);
    }

}
