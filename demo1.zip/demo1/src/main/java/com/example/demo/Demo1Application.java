package com.example.demo;

import com.example.demo.controller.Person;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@MapperScan("com.example.demo.mapper")
@SpringBootApplication
public class Demo1Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext app =  SpringApplication.run(Demo1Application.class, args);
		Person person = (Person) app.getBean("person");
	}

}
