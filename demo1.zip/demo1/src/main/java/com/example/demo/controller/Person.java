package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(value = "prototype")
public class Person {

//    Man man;
//
//    public Person(Man man) {
//        this.man = man;
//    }

    @Autowired
    Man man;


//    Man man;
//
//    @Autowired
//    public void setMan(Man man) {
//        this.man = man;
//    }
}
