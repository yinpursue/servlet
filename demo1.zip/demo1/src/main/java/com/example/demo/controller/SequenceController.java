package com.example.demo.controller;

import com.example.demo.mapper.ISysSequenceDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author
 * @date 2019/12/4 15:49
 */
@RestController

public class SequenceController {

    @Autowired
    private ISysSequenceDao iSysSequenceDao;
    @RequestMapping(value = "/seq",method = RequestMethod.GET)
    public Long sequence(){
//        return 1L;
       return  iSysSequenceDao.selectSequence("tbl_fs");
    }
}
