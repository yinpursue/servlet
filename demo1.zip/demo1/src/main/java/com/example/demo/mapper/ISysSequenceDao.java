package com.example.demo.mapper;

import org.apache.ibatis.annotations.Param;

public interface ISysSequenceDao {

    Long selectSequence(@Param("name") String name);
}
