package com.servlet.service;

import java.sql.SQLException;

import com.servlet.dao.UserDao;
import com.servlet.entity.User;

public class UserService {
	public void registerUser(User user) throws SQLException {
		
		UserDao dao = new UserDao();
		if(dao.getByUserName(user.getUserName())!=null) {
			throw new RuntimeException("�û��Ѵ���");
		}
		dao.addGoddess(user);
	}
	
	public User getByNameAndPassword(String name,String password)  throws SQLException {
		UserDao dao = new UserDao();
		return dao.getByUserNameAndUserPwd(name, password);
	}
}
