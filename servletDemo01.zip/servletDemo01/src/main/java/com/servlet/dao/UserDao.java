package com.servlet.dao;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import com.servlet.db.DbUtil;
import com.servlet.entity.User;

public class UserDao {
	//����
    public void addGoddess(User u) throws SQLException {
        //��ȡ����
        Connection conn = DbUtil.getConnection();
        //sql
        String sql = "INSERT INTO user( user_name, user_pwd,email,birthday)"
                +"values(?,?,?,?)";
        //Ԥ����
        PreparedStatement ptmt = (PreparedStatement) conn.prepareStatement(sql); //Ԥ����SQL������sqlִ��

        //����
        ptmt.setString(1, u.getUserName());
        ptmt.setString(2, u.getUserPwd());
        ptmt.setString(3, u.getEmail());
        ptmt.setDate(4, new Date(u.getBirthday().getTime()));
        
        
        
        //ִ��
        ptmt.execute();
    }

    public void updateGoddess(User u) throws SQLException{
        //��ȡ����
        Connection conn = DbUtil.getConnection();
        //sql, ÿ�мӿո�
        String sql = "UPDATE user" +
                " set user_name=?,  user_pwd=?,email=?,birthday=? where id=?";
        //Ԥ����
        PreparedStatement ptmt = (PreparedStatement) conn.prepareStatement(sql); //Ԥ����SQL������sqlִ��

        //����
        ptmt.setString(1, u.getUserName());
        ptmt.setString(2, u.getUserPwd());
        ptmt.setString(3, u.getEmail());
        ptmt.setDate(4, new Date(u.getBirthday().getTime()));
        

        //ִ��
        ptmt.execute();
    }

    public void delGoddess(Integer id) throws SQLException{
        //��ȡ����
        Connection conn = DbUtil.getConnection();
        //sql, ÿ�мӿո�
        String sql = "delete from user where id=?";
        //Ԥ����SQL������sqlִ��
        PreparedStatement ptmt = (PreparedStatement) conn.prepareStatement(sql);

        //����
        ptmt.setInt(1, id);

        //ִ��
        ptmt.execute();
    }

    public List<User> query() throws SQLException {
        Connection conn = DbUtil.getConnection();
        Statement stmt = (Statement) conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT user_name, user_pwd,email,birthday FROM user");

        List<User> gs = new ArrayList<User>();
        User g = null;
        while(rs.next()){
            g = new User();
            g.setId(rs.getLong("id"));
            g.setUserName(rs.getString("user_name"));
            g.setUserPwd(rs.getString("user_pwd"));
            g.setEmail(rs.getString("email"));
            g.setBirthday(new java.util.Date(rs.getDate("birthday").getTime()));

            gs.add(g);
        }
        return gs;
    }

    public User get(Integer id) throws SQLException{
    	User g = null;
        //��ȡ����
        Connection conn = DbUtil.getConnection();
        //sql, ÿ�мӿո�
        String sql = "select * from  user where id=?";
        //Ԥ����SQL������sqlִ��
        PreparedStatement ptmt = (PreparedStatement) conn.prepareStatement(sql);
        //����
        ptmt.setInt(1, id);
        //ִ��
        ResultSet rs = ptmt.executeQuery();
        while(rs.next()){
        	g = new User();
            g.setId(rs.getLong("id"));
            g.setUserName(rs.getString("user_name"));
            g.setUserPwd(rs.getString("user_pwd"));
            g.setEmail(rs.getString("email"));
            g.setBirthday(new java.util.Date(rs.getDate("birthday").getTime()));
        }
        return g;
    }
    
    public User getByUserName(String userName) throws SQLException{
    	User g = null;
        //��ȡ����
        Connection conn = DbUtil.getConnection();
        //sql, ÿ�мӿո�
        String sql = "select * from  user where user_name=?";
        //Ԥ����SQL������sqlִ��
        PreparedStatement ptmt = (PreparedStatement) conn.prepareStatement(sql);
        //����
        ptmt.setString(1, userName);
        //ִ��
        ResultSet rs = ptmt.executeQuery();
        while(rs.next()){
        	g = new User();
            g.setId(rs.getLong("id"));
            g.setUserName(rs.getString("user_name"));
            g.setUserPwd(rs.getString("user_pwd"));
            g.setEmail(rs.getString("email"));
            g.setBirthday(new java.util.Date(rs.getDate("birthday").getTime()));
        }
        return g;
    }
    public User getByUserNameAndUserPwd(String userName,String userPwd) throws SQLException{
    	User g = null;
        //��ȡ����
        Connection conn = DbUtil.getConnection();
        //sql, ÿ�мӿո�
        String sql = "select * from  user where user_name=? and user_pwd =?";
        //Ԥ����SQL������sqlִ��
        PreparedStatement ptmt = (PreparedStatement) conn.prepareStatement(sql);
        //����
        ptmt.setString(1, userName);
        ptmt.setString(2, userPwd);
        //ִ��
        ResultSet rs = ptmt.executeQuery();
        while(rs.next()){
        	g = new User();
            g.setId(rs.getLong("id"));
            g.setUserName(rs.getString("user_name"));
            g.setUserPwd(rs.getString("user_pwd"));
            g.setEmail(rs.getString("email"));
            g.setBirthday(new java.util.Date(rs.getDate("birthday").getTime()));
        }
        return g;
    }
}
